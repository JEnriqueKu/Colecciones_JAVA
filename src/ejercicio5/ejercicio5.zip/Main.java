package ejercicio5;

public class Main {
    public static void main(String[] args) {
        PaisService ps = new PaisService();

        ps.crearPaises();
        ps.eliminarPais();
    }
}
