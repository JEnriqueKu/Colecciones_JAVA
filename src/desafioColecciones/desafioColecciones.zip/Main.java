package desafioColecciones;

import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        Hotel hotel = new Hotel();

        hotel.menu();
    }
}
